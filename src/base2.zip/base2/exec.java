package base2;

public class exec {

    public static void main(String[] args) {
        Questioner nemo = new Questioner();
        nemo.askQuestion();
        nemo.askQuestion();
        nemo.askQuestion();
        nemo.askQuestion();
        nemo.askQuestion();
        nemo.askQuestion();

    }
}
